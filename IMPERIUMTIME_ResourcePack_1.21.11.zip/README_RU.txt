================================================================================
  IMPERIUMTIME Resource Pack 1.21.11
  Премиальный чёрно-золотой ресурс-пак для сервера
================================================================================

ВЕРСИЯ: Minecraft Java Edition 1.21.11 (pack format 75.0)
АВТОР: IMPERIUMTIME Server
ДАТА: 2026

--------------------------------------------------------------------------------
1. УСТАНОВКА НА КЛИЕНТ
--------------------------------------------------------------------------------
1. Скопируйте файл IMPERIUMTIME_ResourcePack_1.21.11.zip в папку:
   .minecraft/resourcepacks/
2. В игре: Настройки → Ресурс-паки → активируйте «IMPERIUMTIME».
3. Перезапустите мир / переподключитесь к серверу.

--------------------------------------------------------------------------------
2. УСТАНОВКА НА СЕРВЕР (Paper)
--------------------------------------------------------------------------------
Способ A — принудительный ресурс-пак (рекомендуется):
1. Положите ZIP на веб-хостинг (или в папку сервера с HTTP).
2. В server.properties установите:
   resource-pack=https://ВАШ_ДОМЕН/IMPERIUMTIME_ResourcePack_1.21.11.zip
   resource-pack-sha1=<SHA1_хэш_файла>
   require-resource-pack=true
3. Перезапустите сервер.

Способ B — игроки скачивают сами:
   Просто раздайте ZIP и попросите включить в клиенте.

Как получить SHA1:
  sha1sum IMPERIUMTIME_ResourcePack_1.21.11.zip

--------------------------------------------------------------------------------
3. КАСТОМНЫЕ ПРЕДМЕТЫ
--------------------------------------------------------------------------------
Текстуры находятся в namespace «imperiumtime».

Способ 1 (современный, 1.21.4+): компонент item_model
  /give @p paper[minecraft:item_model="imperiumtime:coin"]
  /give @p paper[minecraft:item_model="imperiumtime:ruby"]
  /give @p paper[minecraft:item_model="imperiumtime:gold_ingot"]
  /give @p paper[minecraft:item_model="imperiumtime:crown"]
  /give @p paper[minecraft:item_model="imperiumtime:shield"]
  /give @p paper[minecraft:item_model="imperiumtime:diamond"]
  /give @p paper[minecraft:item_model="imperiumtime:emerald"]
  /give @p paper[minecraft:item_model="imperiumtime:star"]

Способ 2 (CustomModelData, совместимость с плагинами):
  paper с custom_model_data:
    10001 — монета
    10002 — рубин
    10003 — золотой слиток
    10004 — корона
    10005 — щит
    10006 — алмаз
    10007 — изумруд
    10008 — звезда

  Пример (старый синтаксис NBT):
  /give @p paper{CustomModelData:10001} 1

  В плагинах (ItemsAdder, Oraxen, Nexo, ExecutableItems и т.д.)
  указывайте соответствующие ID / CMD.

Список текстур:
  - imperiumtime:item/coin
  - imperiumtime:item/ruby
  - imperiumtime:item/gold_ingot
  - imperiumtime:item/crown
  - imperiumtime:item/shield
  - imperiumtime:item/diamond
  - imperiumtime:item/emerald
  - imperiumtime:item/star

GUI-иконки (для меню плагинов):
  assets/minecraft/textures/gui/
    imperium_confirm.png
    imperium_cancel.png
    imperium_back.png
    imperium_info.png
    imperium_frame.png
    imperium_divider.png

--------------------------------------------------------------------------------
4. SCOREBOARD / HUD
--------------------------------------------------------------------------------
Стандартный scoreboard Minecraft НЕ поддерживает кастомные фоны,
короны и сложное оформление через один ресурс-пак.

Рекомендуемые плагины (существующие):
  • FancyHolograms / DecentHolograms — голограммы
  • TAB (NEZNAMY) — полностью кастомизируемый TAB и scoreboard
  • Scoreboard-revision / AnimatedScoreboard
  • FeatherBoard (если доступен для версии)

В ресурсе подготовлены иконки валют (монета, рубин) для использования
в placeholder-ах TAB / PlaceholderAPI.

Пример конфигурации TAB (tablist.yml / scoreboard):
  header:
    - "&6&l✦ IMPERIUMTIME ✦"
  footer:
    - "&7Онлайн: %server_online%  &6Монеты: %vault_eco_balance%"
    - "&cРубины: %playerpoints_points%"

Для визуального «панельного» scoreboard используйте плагин с поддержкой
GUI или hologram-based HUD.

--------------------------------------------------------------------------------
5. ЭКОНОМИКА
--------------------------------------------------------------------------------
Ресурс-пак НЕ меняет балансы игроков.

Рекомендуемые плагины:
  • Vault + любой economy (EssentialsX, CMI, и т.д.) — монеты
  • PlayerPoints — рубины / поинты
  • CoinsEngine / UltimateEconomy — при необходимости

Иконки валют можно использовать в GUI-меню магазинов
(DeluxeMenus, ChestCommands, FancyMenu, BetterGUI и др.).

--------------------------------------------------------------------------------
6. GUI-МЕНЮ
--------------------------------------------------------------------------------
Текстуры gui/* предназначены для использования в плагинах меню:
  - иконки кнопок подтверждения / отмены / назад / информации
  - декоративные рамки и разделители

В конфигурации плагина укажите путь к текстуре или используйте
предметы с CustomModelData / item_model.

--------------------------------------------------------------------------------
7. ОГРАНИЧЕНИЯ
--------------------------------------------------------------------------------
• Ресурс-пак не создаёт новые предметы в ванильном реестре —
  предметы выдаются через команды / плагины с item_model или CMD.
• Scoreboard не может иметь произвольный фон только средствами RP.
• Шрифты и сложный HUD требуют клиентских модов или плагинов
  с поддержкой bitmap-шрифтов / resource-pack GUI.
• Переопределение paper.json затрагивает отображение бумаги
  с соответствующим CustomModelData — обычная бумага остаётся
  без изменений (fallback).

--------------------------------------------------------------------------------
8. СОДЕРЖИМОЕ АРХИВА
--------------------------------------------------------------------------------
pack.mcmeta
pack.png
README_RU.txt
assets/
  minecraft/
    textures/item/   (legacy-копии)
    textures/gui/
    models/item/paper.json
    items/paper.json
  imperiumtime/
    textures/item/
    models/item/
    items/
sources/             — исходные PNG

================================================================================
